package mayintarlasi;

public class Mayintarlasi {

    public static void main(String[] args) {
       
    }
    
}
