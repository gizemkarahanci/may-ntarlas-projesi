
package mayintarlasi;

abstract class mayintarlasioyunu{
public void oyunbitti(){


}
public void butonac(int kolonsayisi,int sutunsayisi, int mayinsayisi) {
    
}

    
}
